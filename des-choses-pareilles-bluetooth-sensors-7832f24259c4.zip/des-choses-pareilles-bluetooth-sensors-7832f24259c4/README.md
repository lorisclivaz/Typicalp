## Devices
### Ble Beacon Devices
These devices sends data periodically on advertisement channels
- ELA Blue PUCK RHT

### Ble GATT Devices
To get data from theses devices, whe have to connect and request data
- PH60S-Z PH Meter
- BT42 Temperature Probe


## Callback
Once we get a measurement from a device, the callback function *put(measurement, location, value)* is called.
You have to implement this function to process grabbed data.

```python
# iot.py

def put(measurement, location, value):
    """Process grabbed data
    Args:
        measurement (str)   : Name of measurement
        location (str)      : Location of measuremetn
        value (float)       : Measurement value
    """
    # todo implement data management, eg. timeseries storage
    pass
```



## Services
System relies on 3 services. 

On service is for beacon scanner, two other services are for temperature and ph meters.
### Install
````commandline
sudo mv *.service /etc/systemd/system

sudo systemctl enable beacon_scanner.service
sudo systemctl enable ph.service
sudo systemctl enable temperature.service

````
