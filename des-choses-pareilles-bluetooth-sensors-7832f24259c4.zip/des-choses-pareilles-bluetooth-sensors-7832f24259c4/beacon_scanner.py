import signal
import iot

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


from beacontools_custom import BeaconScanner, BtAddrFilter


def callback(bt_addr, rssi, packet, additional_info):
    if hasattr(packet, 'device_name'):
        if packet.device_name.startswith('P RHT'):
            print("<%s, %d> %s %s" % (bt_addr, rssi, packet, additional_info))

            iot.put('temperature', packet.device_name, packet.temperature)
            iot.put('humidity', packet.device_name, packet.humidity)


# scanner = BeaconScanner(callback, bt_device_id=1,
#                         device_filter=[BtAddrFilter("ea:88:77:c9:0d:e4"), BtAddrFilter("cc:9d:96:75:ec:77"), BtAddrFilter("58:2d:34:33:12:40"), BtAddrFilter("f8:21:9f:cb:0e:7d")])

scanner = BeaconScanner(callback, bt_device_id=0)


def handler(signum, frame):
    scanner.stop()
    print(bcolors.WARNING + "Scan stopped" + bcolors.ENDC)


signal.signal(signal.SIGINT, handler)

print(bcolors.WARNING + "Scan started" + bcolors.ENDC)
scanner.start()
