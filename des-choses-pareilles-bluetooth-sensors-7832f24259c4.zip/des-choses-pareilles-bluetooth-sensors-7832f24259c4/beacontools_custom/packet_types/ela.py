from ..const import SERVICE_DATA_TYPE, TEMPERATURE_UUID, RELATIVE_HUMIDITY_UUID, DEVICE_NAME_TYPE

supported_data = [
    {'name': 'temperature', 'uuid': TEMPERATURE_UUID},
    {'name': 'humidity', 'uuid': RELATIVE_HUMIDITY_UUID},
]


class ElaAdvertisement:

    def __init__(self, data):
        self.properties = None

        # populate attributes matching supported data
        try:
            for container in data:
                if container.type == SERVICE_DATA_TYPE:
                    for supported_datum in supported_data:
                        if container.value.service_identifier == supported_datum['uuid']:
                            self.__setattr__(supported_datum['name'], container.value.data)
                elif container.type == DEVICE_NAME_TYPE:
                    self.__setattr__('device_name', container.value.device_name)

        except Exception as e:
            print("Error ElaAdvertisement")
            print(data)

    def __str__(self):
        return str(self.__dict__)
