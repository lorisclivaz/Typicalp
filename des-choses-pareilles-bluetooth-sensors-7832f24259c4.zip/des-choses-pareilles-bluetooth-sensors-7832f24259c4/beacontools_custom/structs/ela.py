from construct import Struct, Byte, Switch, OneOf, Int8sl, Array, \
    Int16ul, Int16ub, Int32ub, GreedyString, GreedyRange, \
    Bytes, BitStruct, BitsInteger, Flag, CString, Embedded, ExprAdapter, obj_, Int16sl

from ..const import TEMPERATURE_UUID, RELATIVE_HUMIDITY_UUID, FLAGS_DATA_TYPE, SERVICE_DATA_TYPE, DEVICE_NAME_TYPE

TemperatureDecimal = ExprAdapter(Int16sl, obj_ / 100, obj_ * 100)

def defa(obj, ctx):
    print('default ----------------------------')

ServiceData = Struct(
    "service_identifier" / Bytes(2),
    "data" / Switch(lambda ctx: ctx.service_identifier, {
        TEMPERATURE_UUID: TemperatureDecimal,
        RELATIVE_HUMIDITY_UUID: Int8sl,
    }, default=Int16ub),
)

DeviceName = Embedded(Struct(
    "device_name" / GreedyString("utf_8")
))

Ela = Struct(
    "length" / Byte,
    "type" / Byte,
    "value" / Switch(lambda ctx: ctx.type, {
        FLAGS_DATA_TYPE: BitStruct(
            "reserved" / BitsInteger(3),
            "le_br_edr_support_host" / Flag,
            "le_br_edr_support_controller" / Flag,
            "br_edr_not_supported" / Flag,
            "le_general_discoverable_mode" / Flag,
            "le_limited_discoverable_mode" / Flag,
        ),
        SERVICE_DATA_TYPE: ServiceData,
        DEVICE_NAME_TYPE: DeviceName
    }, default=Array(lambda ctx: ctx.length - 1, Byte)),
)

ElaFrame = GreedyRange(Ela)
