from pygatt import BLEAddressType

from device import Device

"""All low level structures used for parsing temperature notifications."""
from construct import Struct, Byte, Int8sl, Int24sl

d = Struct("flags" / Byte, "mantissa" / Int24sl, "exponent" / Int8sl)


def convert_temperature(data):
    struct = Struct("flags" / Byte, "mantissa" / Int24sl, "exponent" / Int8sl)
    try:
        parsed = struct.parse(data)
        value = int(parsed.mantissa) * 10 ** int(parsed.exponent)
        return round(value, 1)
    except:
        return None


class Bt42(Device):
    def __init__(self, name, mac, callback):
        super().__init__()
        self.name = name
        self.mac = mac
        self.device = None
        self.last_data_timestamp = None
        self.callback = callback
        self.timeout_counter = 0
        self.timeout = 10
        self.connected = False

    def start(self, adapter):
        self.timeout_counter = 0
        self.connected = False
        if self.device:
            self.device.remove_disconnect_callback(self._on_disconnect)
        self.device = adapter.connect(self.mac, address_type=BLEAddressType.random)
        self.connected = True
        self.device.register_disconnect_callback(self._on_disconnect)
        self.device.subscribe("00002a1e-0000-1000-8000-00805f9b34fb", callback=self.handle_data)

    def _on_disconnect(self, data):
        print('disconnected')
        self.connected = False

    def handle_data(self, handle, value):
        self.last_data_timestamp = None
        temperature = convert_temperature(value)
        self.callback({'name': self.name, 'temperature': temperature})
        self.timeout_counter = 0

    def is_healthy(self):
        return self.connected and self.timeout_counter < self.timeout

    def tick(self):
        self.timeout_counter += 1
        print("device_timeout_counter: {}".format(self.timeout_counter))
