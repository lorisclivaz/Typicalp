import signal
from time import sleep

import pygatt
import sys

import iot

from bt42 import Bt42
from ph60s import Ph60s


def dont_quit(signal, frame):
    print('Catch signal: {}'.format(signal))


def sig_term(signal, frame):
    global term_flag
    print('Catch signal: {}'.format(signal))
    exit(0)


signal.signal(signal.SIGHUP, dont_quit)
signal.signal(signal.SIGTERM, sig_term)


def usage():
    print("Usage : data_grabber.py hcidevice sensor \n"
          "\thcidevice : hci0, hci1, ...\n"
          "\tsensor : ph, temperature, all")
    exit(0)


if len(sys.argv) != 3:
    usage()

hci_device = sys.argv[1]
selected_sensor = sys.argv[2]

adapter = pygatt.GATTToolBackend(hci_device=hci_device)


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def bt42_callback(value):
    print(bcolors.OKGREEN + str(value) + bcolors.ENDC)
    iot.put('temperature', value['name'], value['temperature'])


def ph60s_callback(value):
    print(bcolors.OKGREEN + str(value) + bcolors.ENDC)
    iot.put('temperature', value['name'], value['temperature'])
    iot.put('ph', value['name'], value['ph'])
    iot.put('hold', value['name'], value['hold'])


bt42 = Bt42('bt42-lait', 'd9:5d:09:01:57:81', bt42_callback)
ph60s = Ph60s('ph60s-z', '9a:e7:ba:4f:d4:2e', ph60s_callback)


devices = []

if selected_sensor == "ph":
    devices.append(ph60s)
elif selected_sensor == "temperature":
    devices.append(bt42)
elif selected_sensor == "all":
    devices.append(ph60s)
    devices.append(bt42)

error_count = 0

print(bcolors.OKGREEN + "Starting" + bcolors.ENDC)

while True:

    try:
        adapter.start(reset_on_start=False)

        while True:

            sleep(3)

            for device in devices:
                try:
                    if not device.is_healthy():
                        print("device.start")
                        device.start(adapter)
                        print("device.start.end")
                    print("tick")
                    device.tick()
                    error_count = 0
                except Exception as e:
                    print(bcolors.FAIL + 'Device error: ' + str(e) + bcolors.ENDC)
                    error_count += 1
                    if error_count >= 3:
                        error_count = 0
                        print(
                            bcolors.WARNING + "Restarting adapter-------------------------------------->>" + bcolors.ENDC)

                        adapter.stop()
                        adapter.start(reset_on_start=False)

    except Exception as e:
        print('Adapter error: ' + str(e))
