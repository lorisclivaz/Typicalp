class Device:
    def __init__(self):
        pass

    def start(self, adapter):
        pass

    def is_healthy(self):
        return False

    def tick(self):
        pass