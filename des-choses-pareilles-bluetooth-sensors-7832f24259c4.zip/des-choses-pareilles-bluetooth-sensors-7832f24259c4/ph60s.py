from pygatt import BLEAddressType

from device import Device

"""All low level structures used for parsing temperature notifications."""
from construct import Struct, Byte, Int8sl, Int24sl, GreedyRange, Padding, Int16ub, Int16ul, Computed, this, \
    ExprValidator, obj_

d = Struct("flags" / Byte, "mantissa" / Int24sl, "exponent" / Int8sl)


def convert_temperature(data):
    struct = Struct("flags" / Byte, "mantissa" / Int24sl, "exponent" / Int8sl)
    try:
        parsed = struct.parse(data)
        value = int(parsed.mantissa) * 10 ** int(parsed.exponent)
        return round(value, 1)
    except:
        return None


start_symbol = ExprValidator(Int16ub, obj_ == 0x5316)

ph_format = Struct(
    # frame stucture
    "start" / start_symbol,
    "raw_ph" / Int16ub,
    "raw_flags" / Byte,
    "raw_temperature" / Int16ub,

    # decoding
    "ph" / Computed((this.raw_ph - 6096) / 100),
    "temperature" / Computed((this.raw_temperature - 12288) / 10),
    "hold" / Computed((this.raw_flags & 0x10) != 0),
)


class Ph60s(Device):
    def __init__(self, name, mac, callback):
        super().__init__()
        self.name = name
        self.mac = mac
        self.device = None
        self.last_data_timestamp = None
        self.callback = callback
        self.timeout_counter = 0
        self.timeout = 10
        self.connected = False

    def start(self, adapter):
        self.timeout_counter = 0
        self.connected = False
        if self.device:
            self.device.remove_disconnect_callback(self._on_disconnect)
        self.device = adapter.connect(self.mac, address_type=BLEAddressType.public)
        self.connected = True
        self.device.register_disconnect_callback(self._on_disconnect)
        self.device.subscribe("0000ffe4-0000-1000-8000-00805f9b34fb", callback=self.handle_data)

    def _on_disconnect(self, data):
        print('disconnected')
        self.connected = False

    def handle_data(self, handle, value):
        self.last_data_timestamp = None
        try:
            result = ph_format.parse(value)
            print("flags {:02X}".format(result.raw_flags))
            self.callback({'name': self.name, 'temperature': result.temperature, 'ph': result.ph, 'hold': result.hold})
            self.timeout_counter = 0
        except:
            pass

    def is_healthy(self):
        return self.connected and self.timeout_counter < self.timeout

    def tick(self):
        self.timeout_counter += 1
        print("device_timeout_counter: {}".format(self.timeout_counter))
